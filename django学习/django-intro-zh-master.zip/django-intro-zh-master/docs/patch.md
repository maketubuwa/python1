暂未翻译

官方文档[点此](https://docs.djangoproject.com/en/1.8/intro/contributing/)
